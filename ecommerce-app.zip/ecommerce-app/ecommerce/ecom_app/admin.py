from django.contrib import admin
from ecom_app.models import *

admin.site.register(Order)
admin.site.register(OrderItem)