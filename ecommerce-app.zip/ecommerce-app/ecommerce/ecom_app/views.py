from rest_framework import generics
from .models import Product,Order, OrderItem
from .serializers import ProductSerializer, OrderSerializer, OrderItemSerializer, \
    CustomizedOrderSerializer, OrderListSerializer
from rest_framework.response import Response

class ProductListCreateView(generics.ListCreateAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class ProductDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class OrderCreateView(generics.CreateAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer

    def perform_create(self, serializer):
        serializer.save()

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=201, headers=headers)
    
class OrderItemCreateView(generics.CreateAPIView):
    queryset = OrderItem.objects.all()
    serializer_class = OrderItemSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=201, headers=headers)

    def perform_create(self, serializer):
        serializer.save()

        # Update the total_amount of the order based on the new order item
        order = Order.objects.get(order_id=serializer.validated_data['order_id'].order_id)
        order_items = OrderItem.objects.filter(order_id=serializer.validated_data['order_id'].order_id)

        # Calculate the new total_amount by summing the prices of all order items
        total_amount = sum(item.product_id.price * item.quantity for item in order_items)
        
        # Update the order's total_amount
        order.total_amount = total_amount
        order.save()

class CustomizedOrderView(generics.RetrieveAPIView):
    queryset = Order.objects.all()
    serializer_class = CustomizedOrderSerializer
    lookup_field = 'order_id'

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        return Response(serializer.data)
    
class OrderListView(generics.ListAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderListSerializer