from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from ecom_app.models import Product

class Command(BaseCommand):
    help = 'Populate users and products'

    def handle(self, *args, **options):
        # Create users
        users = ['user1', 'user2', 'user3']
        for username in users:
            User.objects.create_user(username=username, password='password123')

        # Create products
        products = [
            {'name': 'Pepsi', 'price': 40.0, 'stock_quantity': 100, 'description': 'lorem ..'},
            {'name': 'Lays', 'price': 10.0, 'stock_quantity': 100, 'description': 'lorem ..'},
            {'name': 'Oreo', 'price': 10.0, 'stock_quantity': 120, 'description': 'lorem ..'},
        ]
        for product_data in products:
            Product.objects.create(**product_data)

        self.stdout.write(self.style.SUCCESS('Data populated successfully'))
