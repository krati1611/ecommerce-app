from rest_framework import serializers
from .models import Product, Order, OrderItem


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['name', 'description', 'price', 'stock_quantity']
        read_only_fields = ["product_id"]

class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = ['order_id', 'user_id', 'created_at', 'total_amount']
        read_only_fields = ['total_amount']

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['total_amount'] = str(representation['total_amount'])  # Convert total_amount to string
        return representation

class OrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItem
        fields = ['order_item_id', 'order_id', 'product_id', 'quantity']
        read_only_fields = ['order_item_id']

class CustomizedOrderItemSerializer(serializers.ModelSerializer):
    product_id = serializers.SerializerMethodField()

    class Meta:
        model = OrderItem
        fields = ['product_id', 'quantity']

    def get_product_id(self, obj):
        return obj.product_id.product_id

class CustomizedOrderSerializer(serializers.ModelSerializer):
    items = CustomizedOrderItemSerializer(many=True, read_only=True, source='orderitem_set')

    class Meta:
        model = Order
        fields = ['user_id', 'created_at', 'total_amount', 'items']


class OrderListSerializer(serializers.ModelSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = Order
        fields = ['user_id', 'created_at', 'total_amount', 'items']

    def get_items(self, obj):
        order_items = obj.orderitem_set.all()
        return CustomizedOrderItemSerializer(order_items, many=True).data
