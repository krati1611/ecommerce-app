from django.urls import path
from django.contrib import admin
from ecom_app.views import (
    ProductListCreateView, ProductDetailView,
    OrderCreateView, OrderItemCreateView,
    CustomizedOrderView, OrderListView
)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('products/', ProductListCreateView.as_view(), name='product-list-create'),
    path('products/<int:pk>/', ProductDetailView.as_view(), name='product-detail'),
    path('orders/', OrderCreateView.as_view(), name='order-create'),
    path('order-items/', OrderItemCreateView.as_view(), name='order-item-create'),
    path('customized-order/<int:order_id>/', CustomizedOrderView.as_view(), name='customized-order'),
    path('order-list/', OrderListView.as_view(), name='order-list'),
]